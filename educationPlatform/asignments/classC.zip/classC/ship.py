
class Ship:
    def __init__(self, name, year, length, width, height):
        self.name = name
        self.year = year
        self.length = length
        self.width = width
        self.height = height

    def get_volume(self):
        return self.length * self.width * self.height

    def get_age(self, current_year):
        return current_year - self.year

    def is_ordered(self):
        return list(self.name) == sorted(self.name)
