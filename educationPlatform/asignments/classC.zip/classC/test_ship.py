
from ship import ship

ship = Ship(name="Aurora", year=2000, length=30, width=10, height=5)

print("Volume:", ship.get_volume()) 

print("Age in 2023:", ship.get_age(2023))

print("Is name ordered alphabetically?:", ship.is_ordered())  
