def binarySearchIterative(arr, target):
    left, right = 0, len(arr) - 1

    while left <= right:
        mid = (left + right) // 2
        mid_value = arr[mid]

        if mid_value == target:
            return mid
        elif mid_value < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1

def binarySearchRecursive(arr, target, left, right):
    if left > right:
        return -1

    mid = (left + right) // 2
    mid_value = arr[mid]

    if mid_value == target:
        return mid
    elif mid_value < target:
        return binarySearchRecursive(arr, target, mid + 1, right)
    else:
        return binarySearchRecursive(arr, target, left, mid - 1)
    

arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
target = 5
result_iterative = binarySearchIterative(arr, target)
result_recursive = binarySearchRecursive(arr, target, 0, len(arr) - 1)
print(f"Iterative result: {result_iterative}")  # Output: 4
print(f"Recursive result: {result_recursive}")  # Output: 4